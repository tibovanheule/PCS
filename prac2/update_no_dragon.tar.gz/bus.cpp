#include <iostream>
#include "bus.h"
#include "cacheBlock.h"
#include "cache.h"
#include "dram.h"


Bus::Bus(int n_cores){
	N_CORES = n_cores;
}

Bus::~Bus(){

}

/* Method to connect the Dram memory to the bus.
 */
void Bus::addDram(Dram* dram){
	this->dram = dram;
}

/* Method to connect the Caches to the bus.
 */
void Bus::addCache(Cache* cache, int index){
	this->l1cache[index] = cache;
}

/* This method is called by the cache
 * to resolve a cache miss event when
 * trying to read data.
 *
 */
CacheBlock* Bus::busRead(uint64_t addr, uint8_t CACHE_ID){
	busReads ++;
	int i = 0;
	CacheBlock* result = NULL;
	Cache* c = NULL;
	while(i<SIZE && result==NULL){
		c = l1cache[i];
		if(c!=NULL) result = c->replyToBusRead(addr);
		i++;
	}
	return (result!=NULL)?result:dram->readCacheBlockFromDram(addr);
}

/* This method is called by a cache to
 * inform other caches is wrote data to
 * a specific address. This method is only
 * used by the UPDATE and DRAGON protocol.
l *
 * HINT:
 * l1cache[i]->replyToBusUpdate(addr, cacheBlock)
 */
bool Bus::busUpdate(uint64_t addr, uint8_t CACHE_ID, CacheBlock cacheBlock){
	busUpdates ++;
	Cache* c = NULL;
	for (int i=0; i < SIZE;i++){
		c = l1cache[i];
		if(c!= NULL)c->replyToBusUpdate(addr,cacheBlock);
	}
	//Only needed for dragon protocol.
	return false;
}


/* This method is called by the cache to
 * store an evicted cacheBlock in memory.
 */
void Bus::writeBack(CacheBlock cacheBlock){
	dram->writeCacheBlockToDram(cacheBlock);
}

void Bus::analyze(std::stringstream* traceFile){
	*traceFile << "\t" << "busReads:     " << busReads << "\n";
	*traceFile << "\t" << "busUpdates:   " << busUpdates << "\n";
}
